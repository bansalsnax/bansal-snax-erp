# 03 — Database Design

## Core Collections
users, roles, permissions, locations, units, categories, customers, suppliers, transporters, items, boms, bomComponents, orders, orderItems, purchaseOrders, purchaseOrderItems, goodsReceipts, goodsReceiptItems, productionBatches, productionInputs, productionOutputs, workers, workerRates, workerProduction, stockLedger, stockBalances, stockTransfers, stockAdjustments, wastage, workerPayments, notifications, auditLogs, settings.

## Items
Fields include itemCode, itemName, itemType, category, subCategory, units, stock thresholds, supplier and costing fields.

## BOM
BOM header stores item, version, batch size and status. Components reference other items. Recursive expansion supports raw → semi-finished → finished goods.

## Orders
Orders and orderItems are separated to support multiple products per order.

## Inventory
stockBalances is the fast current state. stockLedger is immutable transaction history.

Ledger transaction types should include:
PURCHASE_RECEIPT
PRODUCTION_CONSUMPTION
PRODUCTION_OUTPUT
SALES_DISPATCH
STOCK_TRANSFER_OUT
STOCK_TRANSFER_IN
ADJUSTMENT_IN
ADJUSTMENT_OUT
WASTAGE
RETURN

## Production
Production batches link planned quantities, actual output, inputs, wastage, location and users.

## Batch Traceability
Batch records link purchased/produced material to locations and downstream production.

## Audit
Sensitive changes write to auditLogs.

## Data Integrity
Use references rather than duplicating master data where practical. Preserve historical snapshots for rates/costs that must not change retroactively.

## Indexing
Create Firestore indexes for common queries such as status + date, item + location, item + batch, customer + orderDate, and worker + date.
