# 06 — Claude Development Specification

## Role
Claude is the implementation assistant for the Bansal Snax ERP. It must follow the master specification as the source of truth.

## Development Rules
1. TypeScript only.
2. Reusable components.
3. Business logic in services.
4. No passwords in Firestore.
5. No Firebase Admin credentials in client code.
6. Security Rules must enforce authorization.
7. Use transactions/batched writes for atomic inventory changes.
8. Validate all inputs.
9. Maintain audit logs.
10. Do not silently change schemas.
11. Write tests for critical calculations.
12. Preserve historical costing.
13. Use meaningful IDs and human-readable reference numbers.
14. Add loading, empty and error states.
15. Confirm destructive operations.
16. Keep code modular.

## Required Test Areas
- BOM explosion
- multi-level BOM
- costing
- stock receipt
- production consumption
- production output
- stock transfer
- adjustment
- worker payment
- order status transitions
- permission enforcement
- batch traceability

## Suggested Project Structure
src/app
src/components
src/services
src/lib
src/types
src/hooks
src/utils

## Suggested Services
auth.service.ts
order.service.ts
bom.service.ts
inventory.service.ts
production.service.ts
purchase.service.ts
costing.service.ts
report.service.ts

## Definition of Done
A module is complete only when:
- UI works
- validation works
- permissions work
- Firestore writes are correct
- audit logging is implemented where required
- error states are handled
- tests exist for important business logic
- no direct stock mutation bypasses the ledger
- documentation is updated

## Build Order
1. Project shell/authentication
2. Roles/permissions
3. Master data
4. Items/BOM
5. Inventory ledger
6. Purchasing
7. Orders
8. Production
9. Worker roasting
10. MRP
11. Costing
12. Reports
13. Audit/notifications
14. Hardening and pilot

## Claude Prompting Principle
Claude should implement one module at a time, first describing schema changes and business rules, then writing code, then tests, then checking that the implementation does not violate the master specification.
