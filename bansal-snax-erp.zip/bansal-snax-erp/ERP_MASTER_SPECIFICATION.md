# BANSAL SNAX ERP — MASTER SPECIFICATION

**Version:** 1.0  
**Prepared for:** Bansal Roasted Snacks / Bansal Snax  
**Target platform:** Next.js + React + Firebase  
**Database:** Cloud Firestore  
**Authentication:** Firebase Authentication  
**Hosting:** Firebase Hosting  
**Development assistant:** Claude Code

---

## 1. Purpose

This ERP will manage the complete operational cycle of a roasted-snacks manufacturing business:

**Customer Order → BOM → Material Requirement → Production → Stock Movement → Finished Goods → Dispatch**

The system must support multi-level BOMs, raw/semi-finished/finished goods, manual roasting labour, batch tracking, location-wise stock, purchasing, stock transfers, wastage, costing, reporting, permissions and audit history.

## 2. Recommended Modules

1. Authentication
2. Dashboard
3. Sales & Orders
4. Customers / Parties
5. Products & Items
6. Multi-level BOM
7. Ingredients / Raw Materials
8. Purchasing & Suppliers
9. Production
10. Contract Worker Roasting
11. Inventory
12. Stock Transfers
13. Stock Adjustments
14. Wastage
15. Dispatch
16. Reports
17. Team & Permissions
18. Locations / Units / Settings
19. Notifications
20. Audit Logs

## 3. Technology Architecture

### Frontend
- Next.js
- React
- TypeScript
- Tailwind CSS
- Lucide icons
- Recharts for dashboards

### Backend / Platform
- Firebase Authentication
- Cloud Firestore
- Firebase Storage only for required documents/files
- Firebase Hosting

### Architecture principle
React UI must not contain core business rules. Use service modules such as:
- `order.service.ts`
- `bom.service.ts`
- `inventory.service.ts`
- `production.service.ts`
- `purchase.service.ts`
- `costing.service.ts`

## 4. Authentication & Authorization

Use Firebase Authentication for credentials. Never store plaintext passwords in Firestore.

User profile:
- uid
- employeeId
- name
- email
- phone
- roleId
- department
- status
- createdAt
- lastLoginAt

Use granular permissions:
- orders.view/create/edit/delete/complete
- production.view/create/edit/approve
- purchase.view/create/approve
- inventory.view/transfer/adjust
- reports.view
- team.manage
- settings.manage

Frontend visibility is not security. Firestore Security Rules must enforce authorization.

## 5. Navigation

- Dashboard
- Orders
  - New Order
  - Pending
  - Processing
  - On Hold
  - Completed
  - Cancelled
- Products & BOM
  - Items
  - BOM
  - Costing
- Ingredients
  - Raw Materials
  - Packaging
  - Consumables
- Production
  - Production Planning
  - Production Batches
  - Roasting Records
  - Packaging
  - Wastage
- Purchasing
  - Purchase Orders
  - Goods Receipts
  - Suppliers
- Inventory
  - Stock Overview
  - Stock Ledger
  - Stock Transfer
  - Stock Adjustment
  - Low Stock
- Reports
- Administration

## 6. Item Master

Item types:
- RAW_MATERIAL
- SEMI_FINISHED
- FINISHED_GOOD
- PACKAGING
- CONSUMABLE
- BY_PRODUCT
- WASTE

Fields:
- itemCode
- itemName
- itemType
- category
- subCategory
- baseUnit
- purchaseUnit
- productionUnit
- conversionFactor
- minimumStock
- reorderLevel
- maximumStock
- defaultSupplierId
- active
- currentCost
- averageCost
- lastPurchaseCost
- createdAt
- updatedAt

## 7. Multi-Level BOM

BOMs must support recursive hierarchies.

Example:

Five Grain Mix
- Roasted Soybean
  - Raw Soybean
  - Salt
  - Roasting cost
- Wheat Nuts
  - Raw Wheat
  - Salt
  - Roasting cost
- Roasted Bajra
- Corn Nuts
- Roasted Gram

BOM fields:
- bomId
- itemId
- version
- batchSize
- unit
- status
- effectiveFrom
- effectiveTo

BOM component fields:
- bomId
- componentItemId
- quantity
- unit
- wastagePercent
- sequence

## 8. Costing

Manufacturing cost should be calculated from the hierarchy:

Raw Material Cost
+ Processing Cost
+ Roasting Labour
+ Fuel
+ Seasoning
+ Packaging
+ Expected Wastage
+ Other Manufacturing Costs
= Manufacturing Cost

Costing must retain historical snapshots so later purchase-price changes do not rewrite historical production costs.

Recommended cost fields:
- materialCost
- labourCost
- fuelCost
- processingCost
- packagingCost
- wastageCost
- totalCost
- costPerUnit
- calculatedAt

## 9. Orders

Order status:
- PENDING
- PROCESSING
- ON_HOLD
- COMPLETED
- CANCELLED

Order fields:
- orderNo
- customerId
- orderDate
- expectedDispatchDate
- billingAddress
- shippingAddress
- city
- transporterId
- vehicleNo
- lrNo
- status
- subtotal
- discount
- tax
- total
- notes
- createdBy
- createdAt
- updatedAt

Order line:
- orderId
- itemId
- quantity
- unit
- rate
- discount
- tax
- amount

Orders should be displayed as a Kanban/sticky-note board. Clicking an order opens full details and material requirements.

## 10. Material Requirement Planning

When an order is created or released for production:
1. Read the active BOM.
2. Expand all BOM levels.
3. Calculate gross requirement.
4. Consider existing finished/semi-finished stock.
5. Consider reserved stock.
6. Calculate net requirement.
7. Compare against raw-material stock.
8. Identify shortages.
9. Generate production requirements.

Example:
500 KG Five Grain Mix → calculate component requirements recursively.

## 11. Purchasing

Separate:
### Purchase Order
- poNo
- supplierId
- date
- expectedDate
- status
- line items
- rates
- taxes
- totals

### Goods Receipt / GRN
- grnNo
- supplierId
- purchaseOrderId
- date
- locationId
- item
- quantity
- rate
- batchNo
- expiry/bestBefore
- qualityStatus
- receivedBy

A GRN creates inventory ledger transactions.

## 12. Production

Production must be batch based.

Production batch:
- batchNo
- itemId
- plannedQuantity
- actualQuantity
- inputQuantity
- wastageQuantity
- locationId
- status
- startDate
- completionDate
- createdBy
- approvedBy

Production should generate:
- material consumption
- output stock
- wastage
- labour payable where applicable
- costing snapshot

## 13. Contract Roasting Labour

Worker master:
- workerId
- workerName
- phone
- status

Worker rate:
- workerId
- process
- itemId/processType
- ratePerKg
- effectiveFrom
- effectiveTo

Roasting record:
- date
- workerId
- itemId
- inputQuantity
- outputQuantity
- wastageQuantity
- ratePerKg
- labourAmount
- productionBatchId
- locationId
- recordedBy

Example:
Moong roasting = ₹8/kg; Flakes = ₹4/kg.

The production transaction must update stock and labour payable atomically.

## 14. Inventory

Do not allow users to directly edit stock balances.

Use:
### stockLedger
- transactionId
- itemId
- locationId
- batchId
- transactionType
- quantityIn
- quantityOut
- referenceType
- referenceId
- userId
- timestamp

### stockBalances
- itemId
- locationId
- batchId
- quantity
- reservedQuantity
- availableQuantity
- updatedAt

`stockBalances` is the fast operational view; `stockLedger` is the permanent audit history.

## 15. Locations

Location master examples:
- Raw Material Store
- Roasting Area
- Semi-Finished Store
- Flavouring Area
- Packaging Store
- Finished Goods Store
- Dispatch Area

Stock transfer:
- transferNo
- fromLocationId
- toLocationId
- itemId
- batchId
- quantity
- requestedBy
- approvedBy
- receivedBy
- status
- date

Source and destination stock movements must be atomic.

## 16. Stock Adjustment

Required for:
- spillage
- physical-count differences
- damage
- moisture loss
- production variance
- packaging damage

Fields:
- adjustmentNo
- itemId
- locationId
- batchId
- systemQuantity
- physicalQuantity
- difference
- reason
- approvedBy
- createdBy
- date

## 17. Wastage

Record:
- productionBatchId
- itemId
- quantity
- reason
- stage
- approvedBy
- createdAt

Track expected vs actual yield.

## 18. Batch / Lot Tracking

Food traceability should be built in from V1.

Batch fields:
- batchNo
- itemId
- sourceType
- sourceReference
- productionDate
- purchaseDate
- expiry/bestBefore
- quantity
- locationId
- qualityStatus

The system should eventually support traceability:

Customer Order → Finished Batch → Production Batch → Raw Material Batch.

## 19. Dashboard

Display:
- today's orders
- pending orders
- processing orders
- on-hold orders
- ready-to-dispatch orders
- today's production
- monthly production
- low-stock items
- critical-stock items
- purchase value
- production cost
- worker payable
- operational alerts

## 20. Reports

Sales:
- by product
- by customer
- by city
- by date
- pending/completed

Purchase:
- by supplier
- by item
- by date
- purchase-price history

Production:
- by item
- by date
- by worker
- input vs output
- wastage
- yield
- production cost

Inventory:
- current stock
- stock valuation
- stock movement
- stock by location
- low stock
- adjustments

Labour:
- worker production
- KG produced
- rate/kg
- payable
- paid/pending

## 21. Audit Logs

Record important changes:
- user
- action
- module
- referenceId
- oldValue
- newValue
- timestamp

Examples:
- BOM edited
- stock adjusted
- order completed
- purchase approved
- production approved
- permission changed

## 22. Database Collections

Recommended Firestore collections:

users
roles
permissions
locations
units
categories
customers
suppliers
transporters
items
boms
bomComponents
orders
orderItems
purchaseOrders
purchaseOrderItems
goodsReceipts
goodsReceiptItems
productionBatches
productionInputs
productionOutputs
workers
workerRates
workerProduction
stockLedger
stockBalances
stockTransfers
stockAdjustments
wastage
workerPayments
notifications
auditLogs
settings

## 23. Business Rules

1. Passwords are managed only by Firebase Authentication.
2. Stock cannot be directly edited.
3. Every stock change creates a ledger entry.
4. Stock transfers create both source and destination movements atomically.
5. Production consumes inputs and creates outputs.
6. Production variance creates wastage records.
7. Completed orders cannot be silently edited.
8. Approved purchases and production records require controlled reversal/adjustment.
9. BOM changes are versioned.
10. Historical costs are immutable snapshots.
11. Permissions are enforced server-side through Firestore Security Rules.
12. Every sensitive change is audited.
13. Batch/lot information must be preserved for traceability.
14. Duplicate transactional submissions must be prevented using unique reference numbers/idempotency logic.

## 24. Firebase Recommendation

Firebase is suitable for V1, particularly for a small-to-medium internal ERP requiring real-time data and simple deployment.

Recommended:
- Firebase Authentication
- Cloud Firestore
- Firebase Hosting
- Firebase Storage only when necessary

Design V1 to minimize dependency on Cloud Functions. Move to Blaze when scheduled backend jobs, external integrations or other paid backend services are required.

Set billing alerts and usage monitoring before enabling paid services.

## 25. Claude Development Rules

Claude must:
- use TypeScript
- keep business logic out of page components
- create reusable services
- validate all forms
- use Firestore transactions/batched writes for multi-document inventory operations
- never expose Firebase Admin credentials client-side
- never store passwords in Firestore
- enforce authorization in Firestore Security Rules
- create indexes when required
- handle loading/error/empty states
- confirm destructive actions
- maintain audit logs
- write tests for costing, BOM explosion and stock movements
- avoid duplicate business logic
- preserve backward compatibility when changing schemas

## 26. Suggested Project Structure

src/
  app/
  components/
  services/
  lib/
  types/
  hooks/
  utils/

services:
- auth.service.ts
- order.service.ts
- bom.service.ts
- inventory.service.ts
- production.service.ts
- purchase.service.ts
- costing.service.ts
- report.service.ts

## 27. MVP Phases

### Phase 1
Authentication, users/roles, items, customers, suppliers, locations.

### Phase 2
Orders, BOM, stock ledger, purchasing.

### Phase 3
Production, roasting labour, wastage, stock transfers.

### Phase 4
MRP, costing, batch traceability, dashboards.

### Phase 5
Reports, advanced analytics, automation, integrations.

## 28. Acceptance Criteria

The ERP is ready for pilot use when:
- users can securely log in
- roles restrict unauthorized modules
- items and BOMs can be maintained
- multi-level BOM requirements calculate correctly
- purchases increase stock
- production consumes raw material and creates output
- roasting records calculate worker pay
- stock transfers update both locations
- stock adjustments are audited
- orders move through defined statuses
- completed orders are separated from active orders
- batch traceability is preserved
- reports reconcile with ledger data
- critical actions are audited
- backups/export strategy is tested
