# 05 — UI/UX Design

## Design Direction
Professional, clean and factory-oriented. Prioritize speed and clarity over decorative elements.

## Navigation
Sidebar with Dashboard, Orders, Products & BOM, Ingredients, Production, Purchasing, Inventory, Reports and Administration.

## Dashboard
Cards for orders, production, low stock and dispatch. Follow with order queue, low-stock alerts and production summary.

## Orders
Use a Kanban/sticky-note layout:
Pending | Processing | On Hold | Completed.

Each card shows:
Order number, party, city, product, quantity, dispatch date, transporter and status.

## Item Page
Searchable table with filters by type/category. Detail drawer or page contains master data, stock summary, BOM and costing.

## BOM
Tree/hierarchy view with expandable levels. Show component quantities and estimated cost.

## Production
Factory-friendly entry screen with large quantity fields, worker selection, item, input KG, output KG, wastage and rate.

## Inventory
Show current stock by location and batch. Highlight low/critical stock. Stock movements should be visible as a ledger.

## Forms
Use validation, clear required-field markers, sensible defaults, confirmation for destructive actions and visible save state.

## Responsive Design
Desktop-first for office users; tablet-friendly for factory-floor entries.

## Status Colors
Use consistent semantic status indicators, but never rely on color alone. Include text labels and icons.

## Search
Global search for order number, party, product, ingredient, batch, supplier and worker.

## Notifications
Show low stock, production delays, order holds, pending approvals and other operational alerts.

## Accessibility
Keyboard navigation, readable contrast, labels for controls and accessible dialogs.
