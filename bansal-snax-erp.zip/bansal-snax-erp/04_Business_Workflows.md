# 04 — Business Workflows

## Order
1. Create order.
2. Validate customer and products.
3. Save order as Pending.
4. Calculate available stock.
5. Reserve finished/semi-finished stock where applicable.
6. Calculate net production requirement.
7. Release production.
8. Complete production.
9. Dispatch.
10. Mark order Completed.

## Purchase
Purchase Order → Supplier → Goods Receipt → Quality Check → GRN → Stock Ledger → Stock Balance.

## Production
Production Requirement → Batch → Material Issue → Worker/Process → Roasting/Processing → Input/Output → Wastage → Labour Payable → Stock Update → Completion.

## Roasting Labour
Record worker, item, input KG, output KG and applicable rate. Calculate labour amount. Create production output and payable transaction together.

## Stock Transfer
Transfer Request → Approval → Source Stock Out → Destination Stock In → Ledger entries → Completion.

## Stock Adjustment
Physical count → Difference → Reason → Approval → Ledger adjustment → Audit.

## Wastage
Expected yield vs actual yield → calculate variance → record wastage by stage/reason → include in reporting/costing.

## Material Requirement Planning
Order quantity → explode BOM → gross requirement → subtract usable stock/reservations → net requirement → identify shortage → suggest purchase or production.

## Dispatch
Verify order, finished goods, batch and quantity → create dispatch → reduce stock → record transporter/vehicle/LR → complete order.

## Exception Handling
On Hold may be used for material shortage, quality issue, production delay, customer instruction or logistics issue. Every hold should have a reason.
