# 01 — Product Requirements Document

## Purpose
Build a practical manufacturing ERP for Bansal Roasted Snacks covering orders, production, purchasing, inventory, costing and workforce operations.

## Business Objectives
- Reduce manual registers and duplicate entry.
- Give management a real-time operational view.
- Link orders to actual material requirements.
- Track raw, semi-finished and finished goods.
- Calculate manufacturing cost through multi-level BOMs.
- Record contract roasting labour and payable amounts.
- Maintain location-wise and batch-wise inventory.
- Provide traceability and audit history.

## Users
- Administrator / Owner
- Sales / Order Entry
- Production Manager
- Store / Inventory Manager
- Purchase Manager
- Accounts / Costing
- Factory Supervisor
- Roasting Worker / Worker Entry Operator
- Management / Reporting

## Functional Modules
Authentication; Dashboard; Orders; Customers; Items; BOM; Ingredients; Purchasing; Production; Roasting Labour; Inventory; Stock Transfer; Stock Adjustment; Wastage; Dispatch; Reports; Administration.

## Core Workflow
Customer Order → Material Requirement → Production Planning → Material Issue → Roasting/Processing → Output → Finished Goods → Dispatch → Completion.

## Key Non-Functional Requirements
Security, auditability, mobile/tablet usability on factory floor, fast search, clear status visibility, reliable transactions, scalable data model and easy deployment.

## MVP
Phase 1: users, roles, items, customers, suppliers, locations.
Phase 2: orders, BOM, purchasing, stock ledger.
Phase 3: production, roasting labour, transfers, wastage.
Phase 4: MRP, costing, batch traceability and dashboards.
Phase 5: reports and integrations.
