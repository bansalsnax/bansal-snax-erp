# 02 — System Architecture

## Recommended Stack
- Next.js + React + TypeScript
- Tailwind CSS
- Firebase Authentication
- Cloud Firestore
- Firebase Hosting
- Firebase Storage when required
- Recharts
- GitHub

## Architecture
UI → Application Services → Firebase SDK → Firestore/Auth/Storage.

Business rules must live in service modules, not directly in React pages.

## Authentication
Firebase Authentication manages credentials. Firestore stores user profile and role metadata. Passwords are never stored in Firestore.

## Authorization
Use granular permissions and Firestore Security Rules. UI hiding is only a convenience; it is not a security mechanism.

## Services
auth.service.ts
order.service.ts
bom.service.ts
inventory.service.ts
production.service.ts
purchase.service.ts
costing.service.ts
report.service.ts

## Transactional Principle
Inventory changes must be atomic. Purchase receipt, production consumption/output and stock transfer should use Firestore transactions or batched writes where appropriate.

## Firebase Hosting
Use Firebase Hosting for the frontend. Keep backend dependencies minimal for the Spark-plan MVP. Cloud Functions can be introduced later when scheduled or privileged server-side processing is required.

## Security
- least privilege
- security rules
- audit logs
- validated inputs
- no client-side admin secrets
- controlled destructive actions

## Scalability
Keep domain logic independent from UI and Firebase-specific code where practical so that a future migration to another backend remains possible.
